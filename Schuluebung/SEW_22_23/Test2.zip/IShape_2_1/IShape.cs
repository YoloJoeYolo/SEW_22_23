﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IShape_2_1
{
    internal interface IShape
    {
        public double CalculateArea();
        public double CalculateCircumference();

    }
}
