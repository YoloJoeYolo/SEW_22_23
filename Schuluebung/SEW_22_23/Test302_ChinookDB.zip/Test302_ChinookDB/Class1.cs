﻿namespace Test302_ChinookDB
{
    public class Class1
    {

    }
}