﻿namespace ToDoDB
{
    public class Class1
    {

    }
}